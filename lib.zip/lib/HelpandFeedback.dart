import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_application_1/DataSecurityAndPrivacy(1).dart';
import 'package:flutter_application_1/VIPFAQ.dart';
import 'package:flutter_application_1/childaccount(1).dart';
import 'package:flutter_application_1/setting.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:getwidget/components/accordion/gf_accordion.dart';
import 'package:bubble/bubble.dart';
import 'package:bubble/issue_clipper.dart';



class HelpandFeedback extends StatefulWidget {
  const HelpandFeedback({Key? key, required String title}) : super(key: key);

  @override
  State<HelpandFeedback> createState() => _HelpandFeedbackState();
}

class _HelpandFeedbackState extends State<HelpandFeedback> {
  // List<String> suggestons = [
  //   "USA",
  //   "UK",
  //   "Uganda",
  //   "Uruguay",
  //   "United Arab Emirates"
  // ];
  void showToast() {
    Fluttertoast.showToast(
        msg: 'This is toast notification',
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.red,
        textColor: Colors.yellow);
  }

  @override
  Widget build(BuildContext context) {
    var ScreenSize = MediaQuery.of(context);
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          // toolbarHeight: 65,
          backgroundColor: Colors.white,
          elevation: 0.9,
          automaticallyImplyLeading: false,
          leading: IconButton(
            onPressed: () {
              Navigator.pop(
                context,
                MaterialPageRoute(
                    builder: (context) => HelpandFeedback(
                          title: '',
                        ),
                    maintainState: true),
              );
              // Navigator.push(
              //             context,
              //             MaterialPageRoute(
              //                 builder: (context) =>   faqhome(title: "",),
              //                 maintainState: true),
              //           );
              // Navigator.push(
              //     context,
              //     MaterialPageRoute(
              //         builder: (context) => faqhome(
              //               title: "",
              //             )));
            },
            icon: Icon(
              Icons.arrow_back_ios_new,
              color: Color(0xff6790D3),
            ),
            iconSize: 20.0,
          ),
          centerTitle: true,

          title: Text(
            'FAQ',
            style: TextStyle(
              fontSize: 20,
              color: Color(0xff6790D3),
            ),
          ),
        ),
        body: Center(
            child: ListView.builder(
                itemCount: 1,
                itemBuilder: (BuildContext context, int index) {
                  return Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        children: [
                          SizedBox(
                            height: ScreenSize.size.height * 0.001,
                          ),
                          Container(
                            alignment: Alignment.topLeft,
                            child: Text(
                              "General",
                              style: TextStyle(
                                  fontSize: 17.5, fontWeight: FontWeight.bold),
                            ),
                          ),
                          GFAccordion(
                            titleBorder: Border(),
                            title: "How to update to a vip baby ?",
                            content:
                                "The precedence of operator species that which operator will be evaluated first and next. \nThe associativity specifies the operator direction to be evaluated; it may be left to right or right to left.",
                          ),
                          GFAccordion(
                            title: "How to update to a vip baby. ",
                            content:
                                "The precedence of operator species that which operator will be evaluated first and next. \nThe associativity specifies the operator direction to be evaluated; it may be left to right or right to left.",
                          ),
                          GFAccordion(
                            title: "How to update to a vip baby. ",
                            content:
                                "The precedence of operator species that which operator will be evaluated first and next. \nThe associativity specifies the operator direction to be evaluated; it may be left to right or right to left.",
                          ),
                          GFAccordion(
                            //  titleBorder: Border.all(
                            //   width: 1,
                            // ),
                            // titleBorderRadius:
                            //     BorderRadius.all(Radius.circular(10)),
                            title: "How to update to a vip baby ?",
                            content:
                                "The precedence of operator species that which operator will be evaluated first and next. \nThe associativity specifies the operator direction to be evaluated; it may be left to right or right to left.",
                          ),
                          // SizedBox(
                          //   height: ScreenSize.size.height*0.001
                          // ),
                          GFAccordion(
                            // titleBorder: Border.all(
                            //   width: 1,
                            // ),
                            // titleBorderRadius:
                            //     BorderRadius.all(Radius.circular(10)),
                            //     collapsedTitleBackgroundColor: Colors.white,
                            // contentBorder: Border.all(width: 2.0),
                            //   contentBackgroundColor: Colors.white,
                            // contentBorderRadius:Border.all(),

                            title: "How to update to a vip baby ?",
                            content:
                                "The precedence of operator species that which operator will be evaluated first and next. \nThe associativity specifies the operator direction to be evaluated; it may be left to right or right to left.",
                          ),
                          SizedBox(
                            height: ScreenSize.size.height * 0.001,
                          ),
                          Container(
                              alignment: Alignment.topLeft,
                              child: Text(
                                "Question category",
                                style: TextStyle(
                                    fontSize: 16.5,
                                    fontWeight: FontWeight.bold),
                              )),
                          SizedBox(
                            height: ScreenSize.size.height * 0.001,
                          ),
                          Row(
                            children: [
                              Container(
                                alignment: Alignment.topLeft,
                                child: TextButton(
                                  onPressed: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) => VIPFAQ()));
                                  },
                                  child: Text(
                                    "VIP FAQ",
                                    style: TextStyle(
                                        fontWeight: FontWeight.normal,
                                        color: Colors.black54),
                                  ),
                                ),
                              ),
                              VerticalDivider(
                                color: Colors.black26,
                                width: 10,
                                thickness: 3,
                                indent: 10,
                                endIndent: 10,
                              ),
                              SizedBox(
                                width: ScreenSize.size.width * 0.27,
                              ),
                              Container(
                                alignment: Alignment.topLeft,
                                child: TextButton(
                                  onPressed: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                childAccountData()));
                                  },
                                  child: Text(
                                    "Child Account & Data",
                                    style: TextStyle(
                                        fontWeight: FontWeight.normal,
                                        color: Colors.black54),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: ScreenSize.size.height * 0.001,
                          ),
                          Row(
                            children: [
                              Container(
                                alignment: Alignment.topLeft,
                                child: TextButton(
                                  onPressed: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                DataSecurityAndPrivacy()));
                                  },
                                  child: Text(
                                    "Data Security & Privacy",
                                    style: TextStyle(
                                        fontWeight: FontWeight.normal,
                                        color: Colors.black54),
                                  ),
                                ),
                              ),
                              SizedBox(
                                width: ScreenSize.size.width * 0.07,
                              ),
                              Container(
                                alignment: Alignment.topLeft,
                                child: TextButton(
                                  onPressed: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) => setting()));
                                  },
                                  child: Text(
                                    "Setting",
                                    style: TextStyle(
                                        fontWeight: FontWeight.normal,
                                        color: Colors.black54),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: ScreenSize.size.height * 0.08,
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              SizedBox(
                                height: 10,
                              ),
                              // GestureDetector(
                              //   onTap: (() {
                              //     //  _SuccessMessage2(context);
                              //     Navigator.push(
                              //         context,
                              //         MaterialPageRoute(
                              //             builder: (context) => FeedBack()));
                              //   }),
                              //   child: Container(
                              //     alignment: Alignment.center,
                              //     margin: EdgeInsets.only(left: 85, right: 85),
                              //     height: 40.0,
                              //     child: Material(
                              //       borderRadius: BorderRadius.circular(20.0),
                              //       color: Color(0xff8AB6FF),
                              //       // color: Color.fromARGB(199, 244, 208, 64),
                              //       elevation: 7.0,
                              //       child: GestureDetector(
                              //         onTap: () {
                              //           // _SuccessMessage2(context);
                              //           Navigator.push(
                              //               context,
                              //               MaterialPageRoute(
                              //                   builder: (context) =>
                              //                       FeedBack()));
                              //         },
                              //         child: Center(
                              //           child: Text(
                              //             'Feedback',
                              //             style: TextStyle(
                              //                 color: Colors.white,
                              //                 fontWeight: FontWeight.bold,
                              //                 fontFamily: 'montserrat'),
                              //           ),
                              //         ),
                              //       ),
                              //     ),
                              //   ),
                              // ),
                            ],
                          )
                        ],
                      ));
                })),
      ),
    );
  }

  _SuccessMessage2(BuildContext context) {
    return ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      duration: const Duration(seconds: 2),
      content: Container(
        child: Text(
          "Please Get Your Feedback",
          textAlign: TextAlign.center,
        ),
        padding: const EdgeInsets.all(8),
        height: 40,
        decoration: const BoxDecoration(
            color: Colors.blue,
            borderRadius: BorderRadius.all(Radius.circular(10))),
      ),
      backgroundColor: Colors.transparent,
      behavior: SnackBarBehavior.floating,
      elevation: 0,
    ));
  }
}
