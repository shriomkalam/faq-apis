import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_application_1/Ticket(1).dart';
import 'package:flutter_application_1/discussion.dart';
import 'package:flutter_application_1/model/Ticopen.dart';
import 'package:get/get_connect/http/src/request/request.dart';
import 'package:http/http.dart';
import 'package:http/http.dart ' as http;
import 'package:stream_chat_flutter/stream_chat_flutter.dart';

class TicketOne extends StatefulWidget {
  const TicketOne({super.key});
  @override
  State<TicketOne> createState() => _TicketOneState();
}
// Future<Admin?> futureAlbum() async {
//   http.Response response = await http.post(
//       Uri.parse(
//           'https://infograinsdevelopment.com/Littlest-Precious/api/close-ticket'),
//       headers: {
//         'Authorization':
//             'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiNzUyZDg2ZWJmM2E4NmI0Mzc1NzgyNTk5OTBlNjNkZTc2Y2U1NjJjOGZmN2E5Mjg0NmZmNDQ2MzdjODdhZGE5YjU3ZTFlOTRkYzAyMjkxMTgiLCJpYXQiOjE2Njc0NjA1NjkuNjExNzg4OTg4MTEzNDAzMzIwMzEyNSwibmJmIjoxNjY3NDYwNTY5LjYxMTc5Mzk5NDkwMzU2NDQ1MzEyNSwiZXhwIjoxNjk4OTk2NTY5LjU1MzYzNzAyNzc0MDQ3ODUxNTYyNSwic3ViIjoiMTIyIiwic2NvcGVzIjpbXX0.Yg3EAYOqmR02Suk7_Tq3bo-tOr61R5G90gIgQyfC9n3CeAQwg4NDjRBE1iBSIIKNCcc_8WbHnCluT-HLPMzUqUngS4ZdziYjwusSQ4nk4NJYabnaKyMncedmfwR6vj_CAUMSINiHZTGAwOkdSItbaf4gK2JatTy-ekhV_F1WvXe1eFxVDH5MzYOQvl2LY5o7E0gbVmk5HeLThTpCASMsA9-SVjtpJoqvaSsRHUJp32blZTTaLWhdGenkoDl4b9c6BVSkMuxq9cy_FNVtTKRBUDP_YG3_yKcMru9VxhidFZ1VjbOVQdy9vkjJUlMgnM3dkcaqKET8cmDnfYlvtjSpsohSBiaMILIaCsURA4awBFqPuJdP7_u5FUDK51KIobNzqfJmJkwUKkXW1OrrNP8rBKtPCpOjX-x0ZSw0LRzm-v57_MGlPfI1-_n36qYtFB9TaH0mlroitVtuQMghbkN5KD5tAuF6rxzOCOGs89aWsFvHAxiRuZ6Z8qqTEXE66HIYzxQN4cZw6rGnfMYPqxKfXrGFxPhRO0RP9-KSCNoRyGKC9guUPTBwBhcGxoyNfvmPhvm0Qbe0GkBPMacjybvosKwf5mQGfVLKuIR1pcm7Y6wCAwVs95YSum-tawaMDVccVV666k3juxTj76Y9ES1UvYbO5lGLn5cA1vb1uQSr26g',
//       },
//       body: {
//         "ticket_id": "255",
//       });
//   print(response);
//   var data = jsonDecode(response.body.toString());

//   print(Admin);

//   if (response.statusCode == 200) {
//     //  Map<String, dynamic> user = jsonDecode();
//     //  print('Howdy, ${Admin.data!.data['name']}!');
//     print(Admin.fromJson(data).message);
//     rahu = Admin.fromJson(data).message;

//     return Admin.fromJson(json.decode(response.body));
//   } else {
//     // If the response was umexpected, throw an error.
//     throw Exception('Failed to load post');
//   }
// }

class _TicketOneState extends State<TicketOne> {
  var rahu = " ";
  Future<Ticopen?> futureAlbum() async {
    http.Response response = await http.post(
        Uri.parse(
            'https://infograinsdevelopment.com/Littlest-Precious/api/close-ticket'),
        headers: {
          'Authorization':
              'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiYTZiMmJmMzdiMWNkNDZmZjA1NzM1ZWI3MWQ3Yjc3NWFkYmNkZWRhY2E1NDBkNGZkZWI3NWNhOGRhN2JlZDNiMTAzMzFmMzgyYTg1NTY5OTciLCJpYXQiOjE2NjkyMTAwMDMuNzQ2MTMxODk2OTcyNjU2MjUsIm5iZiI6MTY2OTIxMDAwMy43NDYxMzQwNDI3Mzk4NjgxNjQwNjI1LCJleHAiOjE3MDA3NDYwMDMuNzQ0NDUzOTA3MDEyOTM5NDUzMTI1LCJzdWIiOiIxNTkiLCJzY29wZXMiOltdfQ.UWi7Pd6OILH2jRv_d1ytWY84qrY8Pli05zeRZgC0yMRtfEAPxeehO3OmWH8EK4D-owJzJFaWBdMmWiHC5fLpRQJam6FKUqmRlBx6kUpleS-Tj3eqiFY40bvD0Q2BSy8qaXdKUA1ujQiFoO_0SzyxF4sXCha7kwkgk6cBmxdGd27TGAlCYsh2vBQ0TFeEz1Bfbe6awUCZbiCBaR7QWQ5DyS2SsH0DnOW4jKdZf6sfWwF-bCfLG1vcLcjx1I06JXNAf-Aqfe3CZMe_lPeqFnba7WfWtYMcbX1ZE_2T2XrhPBqu4PPNqMiFu_J-Ev2ktVmMV8h-O59COUga-SjL43eXPTg5sFgNKjmjuFDjy1zTwdoj7kx7whL9BtMOLxFnFRRCNwKixVOFHBAsx-uRK7g6qm7tD9fdg72W2oyDBYadbIVLjHb-iye_L80cqjZox8o7o_IGGLkR5vvAV_tyj2pQ9MxklHQzR3p8et41L-im-tr1TUa3xOcLPUkEog6TuPvgHIBc9YqTMkNtjkBxWtN5ChTV-UHRWWr42L4Gd2Tro2ExN3_imfR5Q2bHBGBmUUwFcR8BDbPoebVod8xVFw8hmYWrVMwqjg9ueKTN4PxMnIkqZ7tORWSnZRtKxxOvESr5wvx07faeg6x5-y-LDpS7zcya1InotS8lW89Giev5N_I',
        },
        body: {
          "ticket_id": "369",
        });
    print(response);
    var data = jsonDecode(response.body.toString());

    print(data);

    if (response.statusCode == 200) {
      //  Map<String, dynamic> user = jsonDecode();
      //  print('Howdy, ${Admin.data!.data['name']}!');
      print(Ticopen.fromJson(data).message);
      rahu = Ticopen.fromJson(data).message;
      setState(() {});
      return Ticopen.fromJson(json.decode(response.body));
    } else {
      // If the response was umexpected, throw an error.
      throw Exception('Failed to load post');
    }
  }

  late Future<Ticopen?> post;
  @override
  void initState() {
    super.initState();
    post = futureAlbum();
  }

  @override
  Widget build(BuildContext context) {
    var ScreenSize = MediaQuery.of(context);

    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.9,
        automaticallyImplyLeading: false,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(
              context,
              MaterialPageRoute(
                  builder: (context) => Ticket(), maintainState: true),
            );
          },
          icon: Icon(Icons.arrow_back_ios),
          color: Color(0xff6790D3),
        ),
        title: Text(
          "Ticket Info",
          style: TextStyle(
            fontSize: 20.0,
            fontWeight: FontWeight.w600,
            color: Color(0xff6790D3),
            fontFamily: 'Montserrat Alternates',
          ),
        ),
        centerTitle: true,
        // titleSpacing: -11,
        actions: [
          Column(
            children: [
              Container(
                width: ScreenSize.size.width * 0.15,
                child: TextButton(
                  child: Text(
                    "close",
                    style: TextStyle(color: Color(0xff6790D3), height: 2),
                  ),
                  onPressed: () {
                    showDialog(
                        context: context,
                        builder: (context) {
                          return Container(
                            child: AlertDialog(
                              title: Text(rahu.toString()),
                              // Text(Response.bytes(request: Message)),
                              actions: [
                                TextButton(
                                    onPressed: () {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) => Ticket(),
                                            maintainState: true),
                                      );
                                    },
                                    child: Text("ok"))
                              ],
                            ),
                          );
                        });
                  },
                ),
              )
            ],
          )
        ],
      ),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Expanded(
                child: SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: Container(
                padding: EdgeInsets.only(top: 3),
                height: ScreenSize.size.height * 0.77,
                width: ScreenSize.size.width,
                child: FutureBuilder<Ticopen?>(
                    future: post,
                    builder: (context, snapshot) {
                      if (snapshot.hasData) {
                        var data1 = snapshot.data!.data.toList();
                        var rahu = snapshot.data!.message;

                        return SingleChildScrollView(
                          child: ListView.builder(
                            itemCount: 1,
                            shrinkWrap: true,
                            padding: EdgeInsets.only(top: 10, bottom: 10),
                            physics: NeverScrollableScrollPhysics(),
                            itemBuilder: (context, index) {
                              return

                                  // Column(
                                  //   children: [
                                  //     Row(
                                  //       children: [
                                  //         Padding(
                                  //             padding:
                                  //                 EdgeInsets.only(left: 10, right: 10)),
                                  //         // Text(snapshot.data!.data.problem),
                                  //         SizedBox(
                                  //           height: 10,
                                  //           width: 8,
                                  //         ),
                                  //         Container(
                                  //             padding: EdgeInsets.only(left: 5, right: 5),
                                  //             color: Color.fromARGB(255, 216, 211, 210),
                                  //             child: Row(children: [
                                  //               Text(snapshot.data!.data.problem),
                                  //               Row(
                                  //                 children: [
                                  //                   Text(
                                  //                     snapshot.data!.data.date,
                                  //                     style: TextStyle(height: 5),
                                  //                   ),
                                  //                 ],
                                  //               )
                                  //             ])),
                                  //       ],
                                  //     ),
                                  //   ],
                                  // );
                                  Container(
                                      padding: EdgeInsets.only(
                                          left: 10,
                                          right: 25,
                                          top: 10,
                                          bottom: 10),
                                      child: Align(
                                          alignment:
                                              (snapshot.data!.data.problem ==
                                                      "receiver"
                                                  ? Alignment.topLeft
                                                  : Alignment.topRight),
                                          child: Container(
                                              decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(20),
                                                  color: (snapshot.data!.data
                                                              .date ==
                                                          "receiver"
                                                      ? Color.fromARGB(
                                                          255, 226, 223, 223)
                                                      : Color.fromARGB(
                                                          153, 246, 236, 236))),
                                              padding: EdgeInsets.all(16),
                                              child: Column(
                                                children: [
                                                  Text(snapshot
                                                      .data!.data.problem),
                                                  SizedBox(
                                                    height: 7,
                                                  ),
                                                  Padding(
                                                    padding: EdgeInsets.only(
                                                        left: 50),
                                                  ),

                                                  // Row(
                                                  //   mainAxisAlignment:
                                                  //       MainAxisAlignment.end,
                                                  //   children: [
                                                  //     Container(
                                                  //       alignment:
                                                  //           Alignment.topLeft,
                                                  //       width:
                                                  //           ScreenSize.size.width *
                                                  //               0.14,
                                                  //       child: TextButton(
                                                  //           child: Text(
                                                  //             "open",
                                                  //           ),
                                                  //           onPressed: () async {
                                                  //             Navigator.push(
                                                  //                 context,
                                                  //                 MaterialPageRoute(
                                                  //                     builder:
                                                  //                         (context) =>
                                                  //                             TicketOne()));
                                                  //           }),
                                                  //     )
                                                  //   ],
                                                  // ),
                                                  Container(
                                                    width:
                                                        MediaQuery.of(context)
                                                                .size
                                                                .width *
                                                            0.75,
                                                    child: Row(
                                                      children: [
                                                        SizedBox(
                                                          width: 20,
                                                        ),
                                                        Text(snapshot
                                                            .data!.data.date),
                                                        SizedBox(
                                                          width: 110,
                                                        ),
                                                      ],
                                                    ),

                                                    // padding: EdgeInsets.only(left: 2),
                                                  ),
                                                  // Column(
                                                  //   children: [
                                                  //     Container(
                                                  //       width:
                                                  //           ScreenSize.size.width *
                                                  //               0.14,
                                                  //       child: TextButton(
                                                  //           child: Text(
                                                  //             "open",
                                                  //           ),
                                                  //           onPressed: () async {
                                                  //             Navigator.push(
                                                  //                 context,
                                                  //                 MaterialPageRoute(
                                                  //                     builder:
                                                  //                         (context) =>
                                                  //                             TicketOne()));
                                                  //           }),
                                                  //     )
                                                  //   ],
                                                  // )
                                                ],
                                              ))));
                            },
                          ),
                        );
                      }
                      return Center(child: CircularProgressIndicator());
                    }),
              ),
            )),
            Stack(children: <Widget>[
              Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                    padding: EdgeInsets.only(left: 10, bottom: 10, top: 10),
                    height: 60,
                    width: double.infinity,
                    color: Colors.white,
                    child: Row(
                      children: <Widget>[
                        GestureDetector(
                          onTap: () {},
                          child: Container(
                            height: 30,
                            width: 30,
                            decoration: BoxDecoration(
                              color: Colors.lightBlue,
                              borderRadius: BorderRadius.circular(30),
                            ),
                            child: Icon(
                              Icons.add,
                              color: Colors.white,
                              size: 20,
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 15,
                        ),
                        Expanded(
                          child: TextField(
                            decoration: InputDecoration(
                                hintText: "Enter Your Problem...",
                                hintStyle: TextStyle(color: Colors.black54),
                                border: InputBorder.none),
                          ),
                        ),
                        SizedBox(
                          width: 15,
                        ),
                        FloatingActionButton(
                          onPressed: () {},
                          child: Icon(
                            Icons.send,
                            color: Colors.white,
                            size: 18,
                          ),
                          backgroundColor: Colors.blue,
                          elevation: 0,
                        ),
                      ],
                    )),
              )
            ])
          ],
        ),
      ),
    );
  }
}
