import 'dart:convert'; //1ans
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_application_1/FeedBack.dart';
import 'package:flutter_application_1/HelpDesk(1).dart';
import 'package:flutter_application_1/Ticketopen(1).dart';
import 'package:flutter_application_1/model/Ticopen.dart';
import 'package:flutter_application_1/model/Tickets.dart';
import 'package:get/get.dart';
import 'package:http/http.dart';
import 'package:http/http.dart ' as http;

class Ticket extends StatefulWidget {
  Ticket({super.key});
  @override
  State<Ticket> createState() => _TicketState();
}

Future<Tickets?> gatPostById() async {
  var response = await http.get(
    Uri.parse(
        'https://infograinsdevelopment.com/Littlest-Precious/api/get-ticket'),
    headers: <String, String>{
      HttpHeaders.acceptHeader: 'application/json',
      'Authorization':
          "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiYTZiMmJmMzdiMWNkNDZmZjA1NzM1ZWI3MWQ3Yjc3NWFkYmNkZWRhY2E1NDBkNGZkZWI3NWNhOGRhN2JlZDNiMTAzMzFmMzgyYTg1NTY5OTciLCJpYXQiOjE2NjkyMTAwMDMuNzQ2MTMxODk2OTcyNjU2MjUsIm5iZiI6MTY2OTIxMDAwMy43NDYxMzQwNDI3Mzk4NjgxNjQwNjI1LCJleHAiOjE3MDA3NDYwMDMuNzQ0NDUzOTA3MDEyOTM5NDUzMTI1LCJzdWIiOiIxNTkiLCJzY29wZXMiOltdfQ.UWi7Pd6OILH2jRv_d1ytWY84qrY8Pli05zeRZgC0yMRtfEAPxeehO3OmWH8EK4D-owJzJFaWBdMmWiHC5fLpRQJam6FKUqmRlBx6kUpleS-Tj3eqiFY40bvD0Q2BSy8qaXdKUA1ujQiFoO_0SzyxF4sXCha7kwkgk6cBmxdGd27TGAlCYsh2vBQ0TFeEz1Bfbe6awUCZbiCBaR7QWQ5DyS2SsH0DnOW4jKdZf6sfWwF-bCfLG1vcLcjx1I06JXNAf-Aqfe3CZMe_lPeqFnba7WfWtYMcbX1ZE_2T2XrhPBqu4PPNqMiFu_J-Ev2ktVmMV8h-O59COUga-SjL43eXPTg5sFgNKjmjuFDjy1zTwdoj7kx7whL9BtMOLxFnFRRCNwKixVOFHBAsx-uRK7g6qm7tD9fdg72W2oyDBYadbIVLjHb-iye_L80cqjZox8o7o_IGGLkR5vvAV_tyj2pQ9MxklHQzR3p8et41L-im-tr1TUa3xOcLPUkEog6TuPvgHIBc9YqTMkNtjkBxWtN5ChTV-UHRWWr42L4Gd2Tro2ExN3_imfR5Q2bHBGBmUUwFcR8BDbPoebVod8xVFw8hmYWrVMwqjg9ueKTN4PxMnIkqZ7tORWSnZRtKxxOvESr5wvx07faeg6x5-y-LDpS7zcya1InotS8lW89Giev5N_I"
    },
  );
  if (response.statusCode == 200) {
    print("hello this is valid${response.body}");
    print("object");

    return Tickets.fromJson(json.decode(response.body));
  } else {
    throw Exception('Failed to load post');
  }
}

class _TicketState extends State<Ticket> {
  late Future<Tickets?> haaa;
  @override
  void initState() {
    super.initState();
    haaa = gatPostById();
  }

  @override
  Widget build(BuildContext context) {
    var ScreenSize = MediaQuery.of(context);
    return Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0.9,
          automaticallyImplyLeading: false,
          leading: IconButton(
            onPressed: () {
              Navigator.pop(
                context,
                MaterialPageRoute(
                    builder: (context) => HelpDesk1(), maintainState: false),
              );
            },
            icon: Icon(Icons.arrow_back_ios),
            color: Color(0xff6790D3),
          ),
          title: Text(
            "Ticket ",
            style: TextStyle(
              fontSize: 20.0,
              fontWeight: FontWeight.w600,
              color: Color(0xff6790D3),
              fontFamily: 'Montserrat Alternates',
            ),
          ),
          centerTitle: true,
          // titleSpacing: -11,
        ),
        body: Column(children: [
          Container(
              padding: EdgeInsets.only(top: 3),
              height: ScreenSize.size.height * 0.77,
              width: ScreenSize.size.width,
              child: FutureBuilder<Tickets?>(
                  future: haaa,
                  builder: (context, snapshot) {
                    print("raja111");
                    if (snapshot.hasData) {
                      print("mukesh222");
                      var data1 = snapshot.data!.data.toList();
                      return SingleChildScrollView(
                        child: ListView.builder(
                          itemCount: data1.length,
                          shrinkWrap: true,
                          padding: EdgeInsets.only(top: 10, bottom: 10),
                          physics: NeverScrollableScrollPhysics(),
                          itemBuilder: (context, index) {
                            return Container(
                                padding: EdgeInsets.only(
                                    left: 10, right: 25, top: 10, bottom: 10),
                                child: Align(
                                    alignment:
                                        (snapshot.data!.data[index].problem ==
                                                "receiver"
                                            ? Alignment.topLeft
                                            : Alignment.topRight),
                                    child: Container(
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(20),
                                            color: (snapshot.data!.data[index]
                                                        .date ==
                                                    "receiver"
                                                ? Color.fromARGB(
                                                    255, 226, 223, 223)
                                                : Color.fromARGB(
                                                    153, 246, 236, 236))),
                                        padding: EdgeInsets.all(10),
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceAround,
                                          children: [
                                            // Image.network(snapshot
                                            //     .data!.data[index].firstImage),
                                            Text(snapshot
                                                .data!.data[index].problem),
                                            Container(
                                              width: MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.80,
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  SizedBox(
                                                    width: 20,
                                                  ),
                                                  Text(snapshot
                                                      .data!.data[index].date),
                                                  SizedBox(
                                                    width: 110,
                                                  ),
                                                  TextButton(
                                                      child: Text(
                                                        "open",
                                                        textAlign:
                                                            TextAlign.right,
                                                      ),
                                                      onPressed: () async {
                                                        Navigator.push(
                                                            context,
                                                            MaterialPageRoute(
                                                                builder:
                                                                    (context) =>
                                                                        TicketOne()));
                                                      }),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ))));
                          },
                        ),
                      );
                    }
                    return Center(child: CircularProgressIndicator());
                  })),
          Stack(children: <Widget>[
            Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                height: ScreenSize.size.height * 0.07,
                width: ScreenSize.size.width * 0.55,
                child: SingleChildScrollView(
                  scrollDirection: Axis.vertical,
                  child: Column(
                    children: [
                      ButtonTheme(
                        minWidth: 500.0,
                        height: 110,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                              primary: Colors.blue,
                              side: BorderSide(color: Colors.white, width: 1),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20.0))),
                          onPressed: (() {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => FeedBack(hashCode),
                                  maintainState: false),
                            );
                          }),

                          //
                          child: const Text(
                            ' Generate Ticket ',
                            style: TextStyle(
                              color: Colors.white,
                              fontFamily: 'Montserrat Alternates',
                              fontWeight: FontWeight.w600,
                              fontSize: 14,
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            )
          ])
        ]));
  }
}
