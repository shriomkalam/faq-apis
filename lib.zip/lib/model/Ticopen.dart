import 'dart:convert';

Ticopen adminFromJson(String str) => Ticopen.fromJson(json.decode(str));

String adminToJson(Ticopen data) => json.encode(data.toJson());

class Ticopen {
    Ticopen({
        required this.status,
        required this.success,
        required this.message,
        required this.data,
    });

    int status;
    bool success;
    String message;
    Data data;

    factory Ticopen.fromJson(Map<String, dynamic> json) => Ticopen(
        status: json["status"],
        success: json["success"],
        message: json["message"],
        data: Data.fromJson(json["data"]),
    );

    Map<String, dynamic> toJson() => {
        "status": status,
        "success": success,
        "message": message,
        "data": data.toJson(),
    };
}

class Data {
    Data({
        required this.id,
        required this.userName,
        required this.profilePic,
        required this.isClose,
        required this.problem,
        this.firstImage,
        this.secondImage,
        this.thirdImage,
        required this.addDate,
        required this.date,
        required this.reply,
    });

    int id;
    String userName;
    String profilePic;
    int isClose;
    String problem;
    dynamic firstImage;
    dynamic secondImage;
    dynamic thirdImage;
    String addDate;
    String date;
    List<Reply> reply;

    factory Data.fromJson(Map<String, dynamic> json) => Data(
        id: json["id"],
        userName: json["user_name"],
        profilePic: json["profilePic"],
        isClose: json["isClose"],
        problem: json["problem"],
        firstImage: json["first_image"],
        secondImage: json["second_image"],
        thirdImage: json["third_image"],
        addDate: json["add_date"],
        date: json["date"],
        reply: List<Reply>.from(json["reply"].map((x) => Reply.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "user_name": userName,
        "profilePic": profilePic,
        "isClose": isClose,
        "problem": problem,
        "first_image": firstImage,
        "second_image": secondImage,
        "third_image": thirdImage,
        "add_date": addDate,
        "date": date,
        "reply": List<dynamic>.from(reply.map((x) => x.toJson())),
    };

  toList() {}
}

class Reply {
    Reply({
        required this.id,
        required this.userName,
        required this.profilePic,
        required this.message,
        this.image,
        required this.addDate,
        required this.date,
    });

    int id;
    String userName;
    String profilePic;
    String message;
    dynamic image;
    String addDate;
    String date;

    factory Reply.fromJson(Map<String, dynamic> json) => Reply(
        id: json["id"],
        userName: json["user_name"],
        profilePic: json["profilePic"],
        message: json["message"],
        image: json["image"],
        addDate: json["add_date"],
        date: json["date"],
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "user_name": userName,
        "profilePic": profilePic,
        "message": message,
        "image": image,
        "add_date": addDate,
        "date": date,
    };
}
