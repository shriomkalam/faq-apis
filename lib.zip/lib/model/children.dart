// To parse this JSON data, do
//
//     final childre = childreFromJson(jsonString);

import 'dart:convert';

Childre childreFromJson(String str) => Childre.fromJson(json.decode(str));

String childreToJson(Childre data) => json.encode(data.toJson());

class Childre {
  Childre({
    required this.status,
    required this.success,
    required this.message,
    required this.data,
  });

  int status;
  bool success;
  String message;
  List<Datum> data;

  factory Childre.fromJson(Map<String, dynamic> json) => Childre(
        status: json["status"],
        success: json["success"],
        message: json["message"],
        data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "status": status,
        "success": success,
        "message": message,
        "data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class Datum {
  Datum({
    required this.id,
    required this.userId,
    required this.childsId,
    required this.isMute,
    required this.isPremium,
    required this.isExpire,
    required this.expireDate,
    required this.isSort,
    required this.isBirthday,
    required this.editOption,
    required this.createBy,
    required this.type,
    required this.name,
    required this.permission,
    required this.dob,
    required this.oldBirthDate,
    required this.oldYear,
    required this.oldMonth,
    required this.oldDay,
    required this.icon,
    required this.gender,
    required this.qrcode,
    required this.members,
    required this.relations,
    required this.customeGroup,
  });

  int id;
  int userId;
  int childsId;
  int isMute;
  String isPremium;
  String isExpire;
  DateTime expireDate;
  int isSort;
  int isBirthday;
  bool editOption;
  String createBy;
  String type;
  String name;
  String permission;
  String dob;
  String oldBirthDate;
  String oldYear;
  String oldMonth;
  String oldDay;
  String icon;
  String gender;
  String qrcode;
  List<Member> members;
  List<dynamic> relations;
  List<dynamic> customeGroup;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
        id: json["id"],
        userId: json["user_id"],
        childsId: json["childs_id"],
        isMute: json["isMute"],
        isPremium: json["isPremium"],
        isExpire: json["isExpire"],
        expireDate: DateTime.parse(json["expireDate"]),
        isSort: json["isSort"],
        isBirthday: json["isBirthday"],
        editOption: json["edit_option"],
        createBy: json["create_by"],
        type: json["type"],
        name: json["name"],
        permission: json["permission"],
        dob: json["dob"],
        oldBirthDate: json["old_birth_date"],
        oldYear: json["old_year"],
        oldMonth: json["old_month"],
        oldDay: json["old_day"],
        icon: json["icon"],
        gender: json["gender"],
        qrcode: json["qrcode"],
        members:
            List<Member>.from(json["members"].map((x) => Member.fromJson(x))),
        relations: List<dynamic>.from(json["relations"].map((x) => x)),
        customeGroup: List<dynamic>.from(json["customeGroup"].map((x) => x)),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "user_id": userId,
        "childs_id": childsId,
        "isMute": isMute,
        "isPremium": isPremium,
        "isExpire": isExpire,
        "expireDate":
            "${expireDate.year.toString().padLeft(4, '0')}-${expireDate.month.toString().padLeft(2, '0')}-${expireDate.day.toString().padLeft(2, '0')}",
        "isSort": isSort,
        "isBirthday": isBirthday,
        "edit_option": editOption,
        "create_by": createBy,
        "type": type,
        "name": name,
        "permission": permission,
        "dob": dob,
        "old_birth_date": oldBirthDate,
        "old_year": oldYear,
        "old_month": oldMonth,
        "old_day": oldDay,
        "icon": icon,
        "gender": gender,
        "qrcode": qrcode,
        "members": List<dynamic>.from(members.map((x) => x.toJson())),
        "relations": List<dynamic>.from(relations.map((x) => x)),
        "customeGroup": List<dynamic>.from(customeGroup.map((x) => x)),
      };
}

class Member {
  Member({
    required this.id,
    required this.memberId,
    required this.name,
    required this.relation,
    required this.permission,
    required this.group,
  });

  int id;
  int memberId;
  String name;
  dynamic relation;
  String permission;
  String group;

  factory Member.fromJson(Map<String, dynamic> json) => Member(
        id: json["id"],
        memberId: json["member_id"],
        name: json["name"],
        relation: json["relation"],
        permission: json["permission"],
        group: json["group"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "member_id": memberId,
        "name": name,
        "relation": relation,
        "permission": permission,
        "group": group,
      };
}
