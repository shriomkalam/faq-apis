import 'dart:convert';
import 'package:flutter/material.dart';


Discuss rahulFromJson(String str) => Discuss.fromJson(json.decode(str));

String rahulToJson(Discuss data) => json.encode(data.toJson());

class Discuss {
  static var length;
  Discuss({
    required this.status,
    required this.success,
    required this.message,
    required this.data,
  });

  int status;
  bool success;
  String message;
  List<Datum> data;

  factory Discuss.fromJson(Map<String, dynamic> json) => Discuss(
        status: json["status"],
        success: json["success"],
        message: json["message"],
        data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "status": status,
        "success": success,
        "message": message,
        "data": List<dynamic>.from(data.map((x) => x.toJson())),
      };

  static map(Map<String, dynamic> Function(dynamic m) param0) {}
}

class Datum {
  Datum({
    required this.id,
    required this.userName,
    required this.profilePic,
    required this.title,
    required this.description,
    required this.addDate,
    required this.date,
    required this.reply,
  });

  int id;
  String userName;
  String profilePic;
  String title;
  String description;
  String addDate;
  String date;
  List<dynamic> reply;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
        id: json["id"],
        userName: json["user_name"],
        profilePic: json["profilePic"],
        title: json["title"],
        description: json["description"],
        addDate: json["add_date"],
        date: json["date"],
        reply: List<dynamic>.from(json["reply"].map((x) => x)),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "user_name": userName,
        "profilePic": profilePic,
        "title": title,
        "description": description,
        "add_date": addDate,
        "date": date,
        "reply": List<dynamic>.from(reply.map((x) => x)),
      };
}
