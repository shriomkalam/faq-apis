import 'dart:convert';
Tickets indiyaFromJson(String str) => Tickets.fromJson(json.decode(str));

String indiyaToJson(Tickets data) => json.encode(data.toJson());

class Tickets {
    Tickets({
        required this.status,
        required this.success,
        required this.message,
        required this.data,
    });

    int status;
    bool success;
    String message;
    List<Datum> data;

    factory Tickets.fromJson(Map<String, dynamic> json) => Tickets(
        status: json["status"],
        success: json["success"],
        message: json["message"],
        data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "status": status,
        "success": success,
        "message": message,
        "data": List<dynamic>.from(data.map((x) => x.toJson())),
    };
}

class Datum {
    Datum({
        required this.id,
        required this.userName,
        required this.profilePic,
        required this.isClose,
        required this.problem,
        this.firstImage,
        this.secondImage,
        this.thirdImage,
        required this.addDate,
        required this.date,
        required this.reply,
    });

    int id;
    String userName;
    String profilePic;
    int isClose;
    String problem;
    dynamic firstImage;
    dynamic secondImage;
    dynamic thirdImage;
    String addDate;
    String date;
    List<dynamic> reply;

    factory Datum.fromJson(Map<String, dynamic> json) => Datum(
        id: json["id"],
        userName: json["user_name"],
        profilePic: json["profilePic"],
        isClose: json["isClose"],
        problem: json["problem"],
        firstImage: json["first_image"],
        secondImage: json["second_image"],
        thirdImage: json["third_image"],
        addDate: json["add_date"],
        date: json["date"],
        reply: List<dynamic>.from(json["reply"].map((x) => x)),
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "user_name": userName,
        "profilePic": profilePic,
        "isClose": isClose,
        "problem": problem,
        "first_image": firstImage,
        "second_image": secondImage,
        "third_image": thirdImage,
        "add_date": addDate,
        "date": date,
        "reply": List<dynamic>.from(reply.map((x) => x)),
    };
}
