// import 'dart:convert';
// import 'dart:io';
// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;

// class InitExample extends StatefulWidget {
//   const InitExample({super.key});

//   @override
//   State<InitExample> createState() => _InitExampleState();
// }

// Future<Rahul?> gatPostById() async {
//   var response = await http.get(
//     Uri.parse(
//         'https://infograinsdevelopment.com/Littlest-Precious/api/discussion'),
//     headers: <String, String>{
//       HttpHeaders.acceptHeader: 'application/json',
//       HttpHeaders.contentTypeHeader: 'charset=UTF-8',
//       'Authorization':
//           "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiNjdmYmM5MDQ2NzAzNmNlYTRiYmY0N2ZlNGNmOTlmMTcxNTU0Y2ExMjE4ZjhjODBjNjg2YjU5ODI1ZDhlZWRlOTdiZmIwYmIzY2M4MTFkMTEiLCJpYXQiOjE2Njc0NTc3MTYuOTY1Njk5OTExMTE3NTUzNzEwOTM3NSwibmJmIjoxNjY3NDU3NzE2Ljk2NTcwNDkxNzkwNzcxNDg0Mzc1LCJleHAiOjE2OTg5OTM3MTYuODcxNjU4MDg2Nzc2NzMzMzk4NDM3NSwic3ViIjoiMTE2Iiwic2NvcGVzIjpbXX0.bJ5fj0LogelbgHTSkdEOuYdXQXCKsJLqbLImQK5G0rdlKmn7hBy9ReVIhQgPqGJjpzgF_na-hkKNJygpv2LFIdK_krkkyzeoxG6UNyOr6BUOdUU_arWWxFn4VS23zOLdv6nmty89oTXsmbu2g9_1OKA1LDx8l-1wjynZ2OHg8378_rrXX5wkF_cNZrfituSca9bWiJndIja2uCJX9O8jr7GLIG82OxLITUmDj7esqMm8ZklRvEDg_jYaedxTs_EkkJJ0RUHJZ3_xhseEHDp1LeEilwCJFtkpHd3_bLgiyCptDtJtiFv1R7_4n9yS7ZZdKIv6j-9OxcppDU6-OmAKb3GuuDuW1oJ0cxY5diroaedrqeZVL-B7pUPhyuIAkhxLl63ZcZJShcfeflePtYEzGf6z0A64YB_tMNel-XRXDBW1XAcVjlmiK15dU759-RkRwns3ke6yIIPpQyygrtzJZHvj0PLNjbt49npyuPWaAFi3sLCwNC9T_JWF0b4ljBIglFErmhAELDYHGDouERr6foWN9AbuFPsoZkUQmk2-rvXX-RYhDoiItF3-5haLDOkyylyBVFj2BXB_Zt1asJymOwAsHHsLr1ZLtjWnDnT1saUEPMZeokwiRzs6huPU_qoiT-rLoXJQyXmW1jf3-mMWbiWS-Fxz3Y-HGZKl4YY7yfg"
//     },
//   );

//   if (response.statusCode == 200) {
//     return Rahul.fromJson(json.decode(response.body));
//   } else {
//     // If the response was umexpected, throw an error.
//     throw Exception('Failed to load post');
//   }
// }

// class _InitExampleState extends State<InitExample> {
//   late Future<Rahul?> post;
//   @override
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//     post = gatPostById();
//   }

//   // int _selectedIndex = 0;

//   // late String selectedRadio;

//   // setSelectedRadio(index) {
//   //   setState(() {
//   //     _selectedIndex = post.toString() as int;
//   //   });
//   // }
//   @override
//   Widget build(BuildContext context) {
//     var ScreenSize = MediaQuery.of(context);

//     return Scaffold(
//       resizeToAvoidBottomInset: false,
//       appBar: AppBar(
//           backgroundColor: Colors.white,
//           title: Text(
//             "Discussion",
//             style: TextStyle(color: Colors.black),
//           )

//           // backgroundColor: Colors.white,
//           // elevation: 1,
//           // automaticallyImplyLeading: false,
//           // leading: IconButton(
//           //   onPressed: () {
//           //     // _SuccessMessage2(context);
//           //     Navigator.pop(context);
//           //   },
//           //   icon: Icon(Icons.arrow_back_ios),
//           //   color: Color(0xff6790D3),
//           // ),
//           // title: Row(
//           //   children: [
//           //     Text(
//           //       "Selected child's account",
//           //       style: TextStyle(
//           //         fontSize: 17.0,
//           //         fontWeight: FontWeight.w600,
//           //         color: Color(0xff6790D3),
//           //         fontFamily: 'Montserrat Alternates',
//           //       ),
//           //     ),
//           //   ],
//           // ),
//           // // titleSpacing: -11,
//           // centerTitle: true,
//           // actions: [
//           //   Row(
//           //     mainAxisAlignment: MainAxisAlignment.spaceAround,
//           //     children: [
//           //       Container(
//           //           // color: Colors.green,
//           //           width: ScreenSize.size.width * 0.22,
//           //           child: IconButton(
//           //             icon: Text(
//           //               "Confirm",
//           //               style: TextStyle(
//           //                 fontSize: 13.0,
//           //                 fontWeight: FontWeight.w600,
//           //                 color: Color(0xff6790D3),
//           //                 fontFamily: 'Montserrat Alternates',
//           //               ),
//           //             ),
//           //             onPressed: () {
//           //               // _SuccessMessage2(context);
//           //               // showToast();
//           //               // Navigator.pop(
//           //               //   context,
//           //               //   MaterialPageRoute(
//           //               //       builder: (context) => FeedBack(),
//           //               //       maintainState: true),
//           //               // );
//           //             },
//           //           )),
//           //     ],
//           //   ),
//           // ],
//           ),
//       body: Container(
//         height: ScreenSize.size.height,
//         width: ScreenSize.size.width,
//         child: FutureBuilder<Rahul?>(
//             future: post,
//             builder: (context, snapshot) {
//               if (snapshot.hasData) {
//                 var data1 = snapshot.data!.data.toList();

//                 return ListView.builder(
//                     itemCount: 2,
//                     itemBuilder: (context, index) {
//                       return Column(
//                         children: [
//                           ListTile(
//                             enabled: true,
//                             enableFeedback: true,
//                             leading: Container(
//                               height: ScreenSize.size.height * 0.21,
//                               width: ScreenSize.size.width * 0.21,
//                             //   child: Image.network(
//                             //       snapshot.data!.data[index].profilePic),
//                             child: Text(      
//                            snapshot.data!.data[index].userName),
//                              ),
//                             subtitle: Text(
//                                 snapshot.data!.data[index].addDate.toString()),
//                             title: Text(snapshot.data!.data[index].description
//                                 .toString()),
//                             // trailing: Container(
//                             //   child: Radio(
//                             //     value: "male",
//                             //     groupValue: index,
//                             //     onChanged: (selectedIndex) async {
//                             //       setSelectedRadio(index);
//                             //     },
//                             //   ),
//                             // ),
//                           )
//                         ],
//                       );
//                     });
//               }
//               return Center(child: CircularProgressIndicator());
//             }),
//       ),
//       //  body: FutureBuilder(
//       //         future: post,
//       //         builder: (context, AsyncSnapshot snapshot) {
//       //           if (!snapshot.hasData) {
//       //             return const Center(
//       //               child: CircularProgressIndicator(),
//       //             );
//       //           } else {
//       //             var data1 = snapshot.data;
//       //             return ListView.builder(
//       //                 itemCount: snapshot.data.length,
//       //                 itemBuilder: (BuildContext context, int index) {
//       //                   return Card(
//       //                     child: Padding(
//       //                       padding: const EdgeInsets.all(12),
//       //                       child: ListTile(
//       //                         leading: const SizedBox(
//       //                           width: 80,
//       //                           height: 80,
//       //                         ),
//       //                         title: const Text("Title"),
//       //                         subtitle: Row(
//       //                           mainAxisAlignment: MainAxisAlignment.center,
//       //                           children: const [
//       //                             Expanded(child: Text("Birhday")),
//       //                             Padding(
//       //                               padding: EdgeInsets.all(5.0),
//       //                               child: Text("price"),
//       //                             )
//       //                           ],
//       //                         ),
//       //                       ),
//       //                     ),
//       //                   );
//       //                 });
//       //           }
//       //         }),
//     );
//   }
// }
