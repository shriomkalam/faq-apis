import 'package:flutter/material.dart';
import 'package:getwidget/components/accordion/gf_accordion.dart';
import 'HelpandFeedback.dart';

class childAccountData extends StatefulWidget {
  const childAccountData({Key? key}) : super(key: key);
  @override
  State<childAccountData> createState() => _childAccountDataState();
}

class _childAccountDataState extends State<childAccountData> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.white,
          leading: IconButton(
            onPressed: () {
               Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                      builder: (context) => HelpandFeedback(
                            title: "",
                          )),
                  (Route<dynamic> route) => false,
                );
            },
            icon: Icon(
              Icons.arrow_back_ios_new,
         color: Color(0xff6790D3),
            ),
            iconSize: 20.0,
          ),
          centerTitle: true,
          elevation: 2,
          title: Text('Child Account & Data',
              style: TextStyle(
                fontSize: 20,
                    color: Color(0xff6790D3),
              )),
        ),
        body: Center(
          child: ListView.builder(
              itemCount: 1,
              itemBuilder: (BuildContext context, int index) {
                return Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(children: [
                      SizedBox(
                        height: 20,
                      ),
                      GFAccordion(
                        title: "How to update to a vip baby ?",
                        content:
                            "The precedence of operator species that which operator will be evaluated first and next. \nThe associativity specifies the operator direction to be evaluated; it may be left to right or right to left.",
                      ),
                      GFAccordion(
                        title: "How to update to a vip baby. ",
                        content:
                            "The precedence of operator species that which operator will be evaluated first and next. \nThe associativity specifies the operator direction to be evaluated; it may be left to right or right to left.",
                      ),
                      GFAccordion(
                        title: "How to update to a vip baby. ",
                        content:
                            "The precedence of operator species that which operator will be evaluated first and next. \nThe associativity specifies the operator direction to be evaluated; it may be left to right or right to left.",
                      ),
                      GFAccordion(
                        title: "How to update to a vip baby ?",
                        content:
                            "The precedence of operator species that which operator will be evaluated first and next. \nThe associativity specifies the operator direction to be evaluated; it may be left to right or right to left.",
                      ),
                    ]));
              }),
        ),
      ),
    );
  }
}
