class ContactModel {
  String name, barthdate;
  bool isSelected;
  ContactModel(this.name, this.barthdate, this.isSelected);
}
