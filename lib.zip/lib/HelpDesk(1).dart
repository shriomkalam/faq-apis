import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_application_1/Ticket(1).dart';
import 'package:flutter_application_1/Ticketopen(1).dart';
import 'package:flutter_application_1/model/Tickets.dart';
import 'package:http/http.dart';
import 'FeedBack.dart';
import 'HelpandFeedback.dart';
import 'discussion.dart';
import 'package:http/http.dart ' as http;

class HelpDesk1 extends StatefulWidget {
  const HelpDesk1({super.key});

  @override
  State<HelpDesk1> createState() => _HelpDesk1State();
}

class _HelpDesk1State extends State<HelpDesk1> {
  TextEditingController textController = TextEditingController();

  void FeedBack(
    String problem,
  ) async {
    try {
      http.Response response = await get(
        Uri.parse(
            'https://infograinsdevelopment.com/Littlest-Precious/api/get-ticket'),
        headers: {
          'Authorization':
              'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiYTViYjkxNmIwZDJhZDBhZWMyNGUxZjU0Y2NhNDdjOGRjMzIxNjVmZGY3ZTE3N2Q4YmRhM2MwN2QwOTg2ZDM2NDE0MmE2MjgwMGZkMzAxNTQiLCJpYXQiOjE2NjU3Mzg0MTguNDA0OTIxMDU0ODQwMDg3ODkwNjI1LCJuYmYiOjE2NjU3Mzg0MTguNDA0OTI3MDE1MzA0NTY1NDI5Njg3NSwiZXhwIjoxNjk3Mjc0NDE4LjMxMDkzMDAxMzY1NjYxNjIxMDkzNzUsInN1YiI6IjEwNCIsInNjb3BlcyI6W119.IV0sVqAGlDFHJjSCisCa3TbcbYeF_WRd3B_zcORoclSwdOE-1WNHuvCywNLGAE37tDgDLiGF6yOOmkasTLxZcb0aKX3majgmyHZyjEfLoeiZFcVzBLlDcrZnVthfDpz2t3bfJ_hnu_TREiAGnQUjJnVznm9a4tlO1apcsuFRptWB6inQDOxf29oHOQ8K1hfAoANIgCkWQkLzVaGKWB1iDDvN0pM7XqSGQ_pP0jMU8BkasPgHrAU34ZvJPzrIFSwE4GbigiOi7IaLk4OzCkw7gOOjMNfz5md4OrcgQdM8VJ5NSWGff17R-tKK0UxlQe9-LG-0-zLVejLSKev9bMIOCU0Z3vEu_47TiMfmgOOavZ4r433IH1F5AAnY8DVFhx_VZ_ayPoXbfCV2-27I3Nf1LA1x4DTeF4ZRlbFKG5XGTGSZ--BCZL7kfdYoS3NgjZnOv4i2yCIHbIel_xKYlvQ5w_6E5_crLaxmq2yfa2jRQ17CZIZuebhm5ajwjuRA3ITh0pZuqohgL-9hc4_uooa-iVtfTuU6GFZovYYUTKxJ-Pl-5t42NfU8gzna_q-XzzqjYumMa6lCLvP_OzvWThRozi8Fq4dIR8L3u4p0iibUwuH7yTgD7xjq28yfKgPx1Y3ssrbgWoJmh-mYQkEz8ezZW5BNUJsYqsxmDv59jLvc1Sw',
          'Accept': 'application/json'
        },
        // body: {
        //   "problem": problem,
        //   "child_id": "402",
        // }
      );
      // print(response);
      // print("object");
      var data = jsonDecode(response.body);
      print(data);
      if (response.statusCode == 200) {
        print(data["tocken"]);
        print(
          {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => Ticket()),
            )
          },
        );
      } else {
        print('failed');
      }
    } catch (e) {
      print(e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    var ScreenSize = MediaQuery.of(context);
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        // toolbarHeight: 65,
        backgroundColor: Colors.white,
        elevation: 1.5,
        automaticallyImplyLeading: false,
        leading: IconButton(
          onPressed: () {
            SystemNavigator.pop();
          },
          icon: Icon(
            Icons.arrow_back_ios_new,
            color: Color(0xff6790D3),
          ),
          iconSize: 20.0,
        ),
        centerTitle: true,

        title: Text(
          'Help Desk',
          style: TextStyle(
            fontSize: 20,
            color: Color(0xff6790D3),
          ),
        ),
      ),
      body: Container(
        height: ScreenSize.size.height,
        width: ScreenSize.size.width,
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          // physics: NeverScrollableScrollPhysics(),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Container(
                    //  color: Colors.green,
                    width: ScreenSize.size.width,
                    child: ListTile(
                      enableFeedback: true,
                      enabled: true,
                      dense: true,
                      tileColor: Colors.white,
                      leading: Text(
                        "FAQ",
                        style: TextStyle(
                          fontSize: 19.0,
                          fontWeight: FontWeight.w600,
                          color: Colors.black,
                          fontFamily: 'Montserrat Alternates',
                        ),
                      ),
                      onTap: (() {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => HelpandFeedback(title: ""),
                              maintainState: true),
                        );
                      }),
                      trailing: IconButton(
                        onPressed: null,
                        icon: Icon(
                          Icons.arrow_forward,
                          color: Colors.black,
                          // color: Color(0xff6790D3),
                        ),
                        iconSize: 20.0,
                      ),
                    ),
                  ),
                ],
              ),
              //         Divider(
              //   height: 1,
              //   thickness: 0.1,
              //   indent: 0,
              //   endIndent: 0,
              //   color: Colors.black,
              // ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Container(
                    //  color: Colors.green,
                    width: ScreenSize.size.width,
                    child: ListTile(
                      enableFeedback: true,
                      enabled: true,
                      dense: true,
                      tileColor: Colors.white,
                      leading: Text(
                        "Discussion",
                        style: TextStyle(
                          fontSize: 19.0,
                          fontWeight: FontWeight.w600,
                          color: Colors.black,
                          fontFamily: 'Montserrat Alternates',
                        ),
                      ),
                      onTap: (() {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => InitExample(),
                              maintainState: true),
                        );
                      }),
                      trailing: IconButton(
                        onPressed: null,
                        icon: Icon(
                          Icons.arrow_forward,
                          color: Colors.black,
                          // color: Color(0xff6790D3),
                        ),
                        iconSize: 20.0,
                      ),
                    ),
                  ),
                ],
              ),
              //            Divider(
              //   height: 1,
              //   thickness: 0.8,
              //   indent: 0,
              //   endIndent: 0,
              //   color: Colors.black,
              // ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Container(
                    //  color: Colors.green,
                    width: ScreenSize.size.width,
                    child: ListTile(
                      enableFeedback: true,
                      enabled: true,
                      dense: true,
                      tileColor: Colors.white,
                      leading: Text(
                        "Ticket",
                        style: TextStyle(
                          fontSize: 19.0,
                          fontWeight: FontWeight.w600,
                          color: Colors.black,
                          fontFamily: 'Montserrat Alternates',
                        ),
                      ),
                      onTap: (() {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => Ticket(),
                              maintainState: true),
                        );
                      }),
                      trailing: IconButton(
                        onPressed: null,
                        icon: Icon(
                          Icons.arrow_forward,
                          color: Colors.black,
                          // color: Color(0xff6790D3),
                        ),
                        iconSize: 20.0,
                      ),
                    ),
                  ),
                ],
              ),
              //              Divider(
              //   height: 1,
              //   thickness: 0.8,
              //   indent: 0,
              //   endIndent: 0,
              //   color: Colors.black,
              // ),
            ],
          ),
        ),
      ),
    );
  }
}
