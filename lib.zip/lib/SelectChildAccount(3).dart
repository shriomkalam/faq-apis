import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_application_1/FeedBack.dart';
import 'package:flutter_application_1/Model/children.dart';
import 'package:flutter_application_1/model/Ticopen.dart';
import 'package:flutter_application_1/modeltry.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

class jockes extends StatefulWidget {
  @override
  State<jockes> createState() => _jockesState();
}

class _jockesState extends State<jockes> {
  var web = 0;
  //  var kalam = " ";

  Future<Childre?> gatPostById() async {
    var response = await http.get(
      Uri.parse(
          'https://infograinsdevelopment.com/Littlest-Precious/api/user-childs'),
      headers: <String, String>{
        HttpHeaders.acceptHeader: 'application/json',
        HttpHeaders.contentTypeHeader: 'charset=UTF-8',
        'Authorization':
            "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiYTZiMmJmMzdiMWNkNDZmZjA1NzM1ZWI3MWQ3Yjc3NWFkYmNkZWRhY2E1NDBkNGZkZWI3NWNhOGRhN2JlZDNiMTAzMzFmMzgyYTg1NTY5OTciLCJpYXQiOjE2NjkyMTAwMDMuNzQ2MTMxODk2OTcyNjU2MjUsIm5iZiI6MTY2OTIxMDAwMy43NDYxMzQwNDI3Mzk4NjgxNjQwNjI1LCJleHAiOjE3MDA3NDYwMDMuNzQ0NDUzOTA3MDEyOTM5NDUzMTI1LCJzdWIiOiIxNTkiLCJzY29wZXMiOltdfQ.UWi7Pd6OILH2jRv_d1ytWY84qrY8Pli05zeRZgC0yMRtfEAPxeehO3OmWH8EK4D-owJzJFaWBdMmWiHC5fLpRQJam6FKUqmRlBx6kUpleS-Tj3eqiFY40bvD0Q2BSy8qaXdKUA1ujQiFoO_0SzyxF4sXCha7kwkgk6cBmxdGd27TGAlCYsh2vBQ0TFeEz1Bfbe6awUCZbiCBaR7QWQ5DyS2SsH0DnOW4jKdZf6sfWwF-bCfLG1vcLcjx1I06JXNAf-Aqfe3CZMe_lPeqFnba7WfWtYMcbX1ZE_2T2XrhPBqu4PPNqMiFu_J-Ev2ktVmMV8h-O59COUga-SjL43eXPTg5sFgNKjmjuFDjy1zTwdoj7kx7whL9BtMOLxFnFRRCNwKixVOFHBAsx-uRK7g6qm7tD9fdg72W2oyDBYadbIVLjHb-iye_L80cqjZox8o7o_IGGLkR5vvAV_tyj2pQ9MxklHQzR3p8et41L-im-tr1TUa3xOcLPUkEog6TuPvgHIBc9YqTMkNtjkBxWtN5ChTV-UHRWWr42L4Gd2Tro2ExN3_imfR5Q2bHBGBmUUwFcR8BDbPoebVod8xVFw8hmYWrVMwqjg9ueKTN4PxMnIkqZ7tORWSnZRtKxxOvESr5wvx07faeg6x5-y-LDpS7zcya1InotS8lW89Giev5N_I"
      },
    );
    var data = jsonDecode(response.body.toString());
    print(data);
    // print(web);
    if (response.statusCode == 200) {
      setState(() {});
      return Childre.fromJson(json.decode(response.body));
    } else {
      throw Exception('Failed to load post');
    }
  }

  late Future<Childre?> post;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    post = gatPostById();
  }

  int _selectedIndex = 0;

  late String selectedRadio;
  String? check;
  setSelectedRadio(index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    print(_selectedIndex);
    print(web);
    // print(check);
    //  print(context);

    var ScreenSize = MediaQuery.of(context);

    return Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 1,
          automaticallyImplyLeading: false,
          leading: IconButton(
            onPressed: () {
              // _SuccessMessage2(context);
              Navigator.pop(context);
            },
            icon: Icon(Icons.arrow_back_ios),
            color: Color(0xff6790D3),
          ),
          title: Row(
            children: [
              Text(
                "Selected child's account",
                style: TextStyle(
                  fontSize: 17.0,
                  fontWeight: FontWeight.w600,
                  color: Color(0xff6790D3),
                  fontFamily: 'Montserrat Alternates',
                ),
              ),
            ],
          ),
          // titleSpacing: -11,
          centerTitle: true,
          actions: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Container(
                    // color: Colors.green,
                    width: ScreenSize.size.width * 0.22,
                    child: IconButton(
                      
                      icon: Text(
                        "Confirm",
                        style: TextStyle(
                          fontSize: 13.0,
                          fontWeight: FontWeight.w600,
                          color: Color(0xff6790D3),
                          fontFamily: 'Montserrat Alternates',
                        ),
                      ),
                   onPressed: () {
  Navigator.push(
    context,
    MaterialPageRoute(builder: (context) =>  FeedBack(web)),
  );
}
                      
                    )),
              ],
            ),
          ],
        ),
        body: Container(
          height: ScreenSize.size.height,
          width: ScreenSize.size.width,
          child: FutureBuilder<Childre?>(
              future: post,
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  var data1 = snapshot.data!.data.toList();
                  return ListView.builder(
                      itemCount: data1.length,
                      itemBuilder: (context, index) {
                        return Column(
                          children: [
                            ListTile(
                              enabled: true,
                              enableFeedback: true,
                              leading: Container(
                                height: ScreenSize.size.height * 0.21,
                                width: ScreenSize.size.width * 0.21,
                                child: Image.network(
                                    snapshot.data!.data[index].icon),
                              ),
                              subtitle: Text(
                                  snapshot.data!.data[index].dob.toString()),
                              title: Text(
                                  snapshot.data!.data[index].name.toString()),
                              trailing: Container(
                                child: Radio(
                                  activeColor: Colors.blue,
                                  value: _selectedIndex,
                                  groupValue: index,
                                  onChanged: (selectedIndex) async {
                                    setSelectedRadio(index);
                                    snapshot.data!.data[index].childsId;
                                    web = snapshot.data!.data[index].childsId;
                                    // rahu = kalam;
                                  },
                                ),
                              ),
                            )
                          ],
                        );
                      });
                }
                return Center(child: CircularProgressIndicator());
              }),
        )
        //  body: FutureBuilder(
        //         future: post,
        //         builder: (context, AsyncSnapshot snapshot) {
        //           if (!snapshot.hasData) {
        //             return const Center(
        //               child: CircularProgressIndicator(),
        //             );
        //           } else {
        //             var data1 = snapshot.data;
        //             return ListView.builder(
        //                 itemCount: snapshot.data.length,
        //                 itemBuilder: (BuildContext context, int index) {
        //                   return Card(
        //                     child: Padding(
        //                       padding: const EdgeInsets.all(12),
        //                       child: ListTile(
        //                         leading: const SizedBox(
        //                           width: 80,
        //                           height: 80,
        //                         ),
        //                         title: const Text("Title"),
        //                         subtitle: Row(
        //                           mainAxisAlignment: MainAxisAlignment.center,
        //                           children: const [
        //                             Expanded(child: Text("Birhday")),
        //                             Padding(
        //                               padding: EdgeInsets.all(5.0),
        //                               child: Text("price"),
        //                             )
        //                           ],
        //                         ),
        //                       ),
        //                     ),
        //                   );
        //                 });
        //           }
        //         }),

        );
  }
}
